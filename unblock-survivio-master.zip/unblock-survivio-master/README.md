# unblock-survivio
This is a GitHub repo that uses an iframe to bypass a Chrome extension that blocks games and stuff. My fellow students are particulary fond of Surviv.io, but the extension blocked the websites for it. Some websites worked, but fullscreen didn't work.
<br>
The solution? Make something that can bypass it.
<br>

So I did.
## Things that are Not Games
### [Click Here to Access Bing](https://randomblock1.github.io/unblock-survivio/bing.html "Note: you can’t click links")

## Games
### [Click Here to Access Surviv.io](https://randomblock1.github.io/unblock-survivio/survivio.html "Surviv.io Unblocked!")
### [Click Here to Access Shell Shockers](https://randomblock1.github.io/unblock-survivio/shellshockers.html "Shell Shockers Unblocked!")
### [Click Here to Access Bonk.io](https://randomblock1.github.io/unblock-survivio/bonk.html "Bonk.io Unblocked!")
Share this link to help others have fun! [bit.ly/surviv-io](http://bit.ly/surviv-io)
### [Click Here to Access OurWorld](https://randomblock1.github.io/unblock-survivio/ourworld.html "OurWorld Unblocked!")
<br><br><br><br><br><br><br><br>

Powered by [Randomblock1’s GitHub repo](https://github.com/Randomblock1/unblock-survivio) and made with ❤️

Note: if you fork this, the paragraph that says “powered by randomblock1’s github repo” must be preserved and not removed or edited on any page. Thanks.
